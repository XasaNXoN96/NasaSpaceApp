// UI-1: in RU/UZ, ALIAS rewrites a native word to English, but the RU/UZ index holds translated text,
// so common words ("солнце", "буря", "вода", "quyosh", "suv") return ZERO results although matches exist.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadSearch } from './ui__search_lib.mjs';

const ru = loadSearch('ru'), uz = loadSearch('uz');
const without = (s, w) => { const v = s.ALIAS[w]; delete s.ALIAS[w]; const n = s.search(w).length; s.ALIAS[w] = v; return n; };

for (const [s, lang, w] of [[ru, 'ru', 'буря'], [ru, 'ru', 'солнце'], [ru, 'ru', 'вода'], [ru, 'ru', 'сигнал'], [uz, 'uz', 'quyosh'], [uz, 'uz', 'suv']]) {
  test(`${lang}: searching "${w}" finds the items whose translated text contains it`, () => {
    const literal = without(s, w);
    assert.ok(literal > 0, 'precondition: translated index really contains the word');
    assert.equal(s.search(w).length, literal, `"${w}" -> ${s.search(w).length} results, but ${literal} items contain it`);
  });
}
