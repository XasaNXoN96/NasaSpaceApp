import test from 'node:test';
import assert from 'node:assert/strict';
import { load } from './media__harness.mjs';

test('sanity: every scene of every film paints without throwing (poster + 40 samples/scene)', () => {
  const h = load();
  const F = h.Films.FILMS; const errors = [];
  for (const id of Object.keys(F)) {
    const f = F[id];
    assert.ok(f.posterAt[0] < f.scenes.length, id + ' posterAt in range');
    try { f.poster; } catch (e) { errors.push(id + ' poster: ' + e.message); }
    h.Films.open(id);
    for (let k = 0; k <= 40 * f.scenes.length; k++) {
      h.els['film-seek'].value = String(Math.round(k / (40 * f.scenes.length) * 1000));
      h.els['film-seek'].fire('input');
      try { h.frame(); } catch (e) { errors.push(id + ' @' + k + ': ' + e.message); break; }
    }
    h.els.film.closeBtn.fire('click');
  }
  assert.deepEqual(errors, []);
});

test('BUG: Narration switched off in Settings is ignored by the film player', () => {
  const h = load();
  h.Snd.set('voice', false);                  // what #st-voice change does (ui.js:125)
  h.Films.open('sojourner');
  h.els['film-big'].fire('click');            // press play
  for (let i = 0; i < 400; i++) h.frame(16);  // ~6.4 s: past the title card into scene 2
  assert.equal(h.Snd.cfg.voice, false);
  assert.deepEqual(h.spoken, [], 'nothing should be spoken with narration off');
  assert.equal(h.els['film-voice'].textContent, 'Narration off', 'film button should reflect the setting');
});

test('BUG: paused player keeps repainting the full frame every animation frame', () => {
  const h = load();
  h.Films.open('voyager');                    // opens paused
  h.frame(16);
  const before = h.counter.paints;
  for (let i = 0; i < 60; i++) h.frame(16);   // 1 s while paused
  const perSec = h.counter.paints - before;
  assert.ok(perSec <= 1, 'paused film painted ' + perSec + ' full frames in 1 s (expected ~0)');
});

test('BUG: after a film ends and is replayed, pausing shows the "Watch again" (↻) control, which only resumes', () => {
  const h = load();
  h.Films.open('voyager');
  const big = h.els['film-big'];
  big.fire('click');
  const len = h.Films.FILMS.voyager.length;
  for (let i = 0; i < Math.ceil(len / .1) + 20; i++) h.frame(100);   // play to the end
  assert.equal(big.textContent, '↻');
  big.fire('click');                          // watch again
  for (let i = 0; i < 50; i++) h.frame(100);  // 5 s in
  h.els['film-play'].fire('click');           // pause mid-film
  assert.equal(big.hidden, false);
  assert.notEqual(big.attrs['aria-label'], 'Watch again', 'mid-film pause labelled "Watch again" but clicking resumes, not restarts');
});

test('control: close cancels the rAF loop; reopen leaves exactly one loop', () => {
  const h = load();
  h.Films.open('spirit'); h.frame();
  h.els.film.closeBtn.fire('click');
  assert.equal(h.rafPending(), 0);
  h.Films.open('spirit'); h.Films.open('opportunity');
  h.frame();
  assert.equal(h.rafPending(), 1);
});
