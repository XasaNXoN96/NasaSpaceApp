// Hypothesis: on low-memory devices release() drops a downloaded model, but markerSets keeps the part
// markers keyed by object id and attached to the OLD (disposed, off-scene) holder. When the model is shown
// again, partsFor(id, newHolder) returns the cached set, so the markers are never on the new model.
import { test } from 'node:test';
import assert from 'node:assert';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const html = readFileSync(new URL('../../public/index.html', import.meta.url), 'utf8');
const slice = (a, b) => { const i = html.indexOf(a), j = html.indexOf(b, i); assert.ok(i > 0 && j > i, a); return html.slice(i, j); };
const code = slice('function release(url, holder)', 'function updateLoader()') + '\n' +
             slice('const markerSets = new Map();', 'const ray = new THREE.Raycaster()');

class Obj { constructor() { this.children = []; this.parent = null; this.scale = { x: 1 }; this.position = new V(); this.userData = {}; }
  add(...o) { o.forEach(c => { this.children.push(c); c.parent = this; }); }
  traverse(f) { f(this); this.children.forEach(c => c.traverse ? c.traverse(f) : f(c)); } }
class V { constructor(x = 0, y = 0, z = 0) { Object.assign(this, { x, y, z }); }
  multiplyScalar() { return this; } add() { return this; } clone() { return new V(this.x, this.y, this.z); } copy() { return this; } setScalar() {} }
const THREE = { Group: Obj, Vector3: V,
  Sprite: class extends Obj { constructor(m) { super(); this.material = m; this.scale = { setScalar() {} }; } },
  SpriteMaterial: class { constructor(o) { Object.assign(this, o); } dispose() {} } };
const MER = 'mer.glb';
const ctx = { THREE, window: { SPACE_PARTS: { spirit: { space: 'holder', parts: [{ p: [0, 1, 0], t: 'Mast', d: 'x' }] } } },
  markerTex: { isTexture: true, dispose() {} }, BUILDERS: {}, files: new Map(), progress: new Map(), MER };
vm.createContext(ctx);
vm.runInContext(code + '\nthis.partsFor = partsFor; this.release = release;', ctx);

test('markers follow the model after a low-memory release and reload', () => {
  const holder1 = new Obj(); holder1.add(new Obj());
  const set1 = ctx.partsFor('spirit', holder1);
  assert.strictEqual(set1.group.parent, holder1);
  ctx.release(MER, holder1);                       // lowMemory swap to another model (index.html:1029)
  const holder2 = new Obj(); holder2.add(new Obj()); // spirit shown again: freshly downloaded holder
  const set2 = ctx.partsFor('spirit', holder2);
  assert.strictEqual(set2.group.parent, holder2, 'marker group should be attached to the holder now on stage');
});
