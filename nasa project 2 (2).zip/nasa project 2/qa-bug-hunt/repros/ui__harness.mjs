// Shared loader for ui-i18n repros: runs the REAL public/js files in node:vm with minimal stubs.
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const JS = path.resolve(here, '..', '..', 'public', 'js');
export const src = (f) => fs.readFileSync(path.join(JS, f), 'utf8');

export function makeStorage(init = {}) {
  const m = new Map(Object.entries(init));
  return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), _m: m };
}

// A context with i18n-strings + i18n (+ learn-data, data) loaded for the given language.
export function loadI18n(lang = 'ru', { withLearn = true, withData = false } = {}) {
  const ctx = {
    console,
    localStorage: makeStorage({ 'spaceedu.lang': lang }),
    NodeFilter: { SHOW_ELEMENT: 1, SHOW_TEXT: 4, FILTER_ACCEPT: 1, FILTER_REJECT: 2 },
    MutationObserver: class { observe() {} },
    document: {
      documentElement: {},
      title: '',
      body: { nodeType: 1, tagName: 'BODY', getAttribute: () => null },
      createTreeWalker: () => ({ nextNode: () => null }),
      querySelector: () => null,
    },
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(src('i18n-strings.js'), ctx, { filename: 'i18n-strings.js' });
  vm.runInContext(src('i18n.js'), ctx, { filename: 'i18n.js' });
  if (withData) vm.runInContext(src('data.js'), ctx, { filename: 'data.js' });
  if (withLearn) vm.runInContext(src('learn-data.js') + '\n;window.GLOSSARY=GLOSSARY;window.TAGS=TAGS;window.QUESTIONS=QUESTIONS;', ctx, { filename: 'learn-data.js' });
  return ctx;
}

// Pull a slice of the real ui.js source, from the line containing `from` up to (not incl.) the line containing `to`.
export function slice(file, from, to) {
  const lines = src(file).split('\n');
  const a = lines.findIndex((l) => l.includes(from));
  const b = lines.findIndex((l, i) => i > a && l.includes(to));
  if (a < 0 || b < 0) throw new Error('marker not found: ' + from + ' / ' + to);
  return lines.slice(a, b).join('\n');
}
