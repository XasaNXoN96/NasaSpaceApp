// Repro for live-data partition: loads the REAL code text from public/js (site.js functions are
// sliced out of the IIFE by name and evaluated in a node:vm context with minimal stubs).
// Run: node "qa-bug-hunt/repros/livedata__site_live.mjs"
import { test } from 'node:test';
import assert from 'node:assert';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const js = (f) => fs.readFileSync(path.join(here, '..', '..', 'public', 'js', f), 'utf8');
const site = js('site.js');
const fixture = JSON.parse(fs.readFileSync(path.join(here, 'livedata__m20_waypoints_fixture.json'), 'utf8'));

// slice "function name(...) { ... }" or "var name = function..." from site.js by brace matching
function slice(src, startToken) {
  const s = src.indexOf(startToken); if (s < 0) throw new Error('not found: ' + startToken);
  let i = src.indexOf('{', s), depth = 0;
  for (; i < src.length; i++) { if (src[i] === '{') depth++; else if (src[i] === '}' && --depth === 0) break; }
  let end = i + 1; if (src[end] === ';') end++;
  return src.slice(s, end);
}

function ctx() {
  const c = { Date, Math, Number, String, Error, Promise, console };
  vm.createContext(c);
  vm.runInContext(js('voyager-ephemeris.js') + js('astro.js'), c);
  vm.runInContext([
    "var DAY = 86400000, AU = Astro.AU, C_KMS = 299792.458;",
    "var pad = function(n) { return String(n).padStart(2, '0'); };",
    "var fmt = function(n, d) { return n.toLocaleString('en-US', { maximumFractionDigits: d || 0, minimumFractionDigits: d || 0 }); };",
    slice(site, 'function voyager(ms)'),
    slice(site, 'function hms(sec)'),
    "var M20_LAND = Date.UTC(2021, 1, 18, 20, 55, 0);",
    slice(site, 'var marsSol = function'),
  ].join('\n'), c);
  return c;
}

test('Perseverance card: latest waypoint is a mid-drive localization -> shows 0.00 km driven', async () => {
  const c = ctx();
  const out = {};
  c.set = (id, v) => { out[id] = v; };
  c.$ = () => null;
  c.fetch = (url) => Promise.resolve(url.includes('waypoints')
    ? { ok: true, json: () => Promise.resolve(fixture.sol1896) }        // real rows; file ended on the sol-1896 mid-drive row
    : { ok: false, status: 503, json: () => Promise.resolve({}) });
  vm.runInContext('var m20Fetched = false, refreshing = false;\n' + slice(site, 'function fetchM20()'), c);
  c.fetchM20();
  await new Promise((r) => setTimeout(r, 50));
  console.log('rendered:', JSON.stringify(out));
  // expected: the rover's total distance (42.51 km at the last end-of-drive row), never 0
  assert.notStrictEqual(out['lv-m20'], '0.00 km', 'Driven on Mars shows "0.00 km"');
});

test('Voyager 1 time travel (-300 days): Earth distance must stay within 1 AU of Sun distance', () => {
  const c = ctx();
  const today = Date.UTC(2026, 9, 24, 12);
  for (const days of [0, -300, -730]) {
    const v = c.voyager(today + days * 86400000);
    console.log(`offset ${days} d: sunAU=${v.sunAU.toFixed(2)} earthAU=${v.earthAU.toFixed(2)} diff=${(v.earthAU - v.sunAU).toFixed(2)} light=${c.hms(v.earthKm / 299792.458)}`);
  }
  const v = c.voyager(today - 300 * 86400000);
  assert.ok(Math.abs(v.earthAU - v.sunAU) <= 1.0, `|earthAU - sunAU| = ${Math.abs(v.earthAU - v.sunAU).toFixed(2)} AU (Earth is 1 AU from the Sun)`);
});

test('Voyager 1 today and the data.js "1 light-day on Nov. 18, 2026" claim agree (sanity)', () => {
  const c = ctx();
  const lightDayAU = 86400 * 299792.458 / 149597870.7;
  let d = Date.UTC(2026, 9, 24);
  while (c.voyager(d).earthAU < lightDayAU) d += 3600000;
  console.log('one light-day crossed at', new Date(d).toISOString(), '| today light-time', c.hms(c.voyager(Date.UTC(2026, 9, 24, 16)).earthKm / 299792.458), '| speed', c.voyager(Date.UTC(2026,9,24)).sunKms.toFixed(2), 'km/s');
  // 03:00 UTC Nov 19 = evening of Nov 18 in US time; 5-day linear rows -> allow 1.5 days
  assert.ok(Math.abs(d - Date.UTC(2026, 10, 18, 12)) < 1.5 * 86400000);
});

test('Sol clock: local mean solar time at a NASA raw image timestamp matches the feed', () => {
  const c = ctx();
  // NASA raw-image feed (fetched 2026-10-24): date_taken_utc 2026-10-24T08:40:07.188, date_taken_mars "Sol-02018M16:21:24.441"
  const t = Date.UTC(2026, 9, 24, 8, 40, 7, 188);
  const solFloat = vm.runInContext(`.662 + (${t} - M20_LAND) / 88775244`, c);
  const lmstMin = (solFloat % 1) * 24 * 60, feedMin = 16 * 60 + 21.4;
  console.log('sol', c.marsSol(t), 'code LMST', Math.floor(lmstMin / 60) + ':' + String(Math.floor(lmstMin % 60)).padStart(2, '0'), 'feed LMST 16:21', 'error min', (lmstMin - feedMin).toFixed(1));
  assert.strictEqual(c.marsSol(t), 2018);
  assert.ok(Math.abs(lmstMin - feedMin) < 2, `sol clock off by ${(lmstMin - feedMin).toFixed(1)} min -> sol number rolls over late`);
});
