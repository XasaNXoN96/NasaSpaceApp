// Hypothesis: on a non-Missions page (hero hidden, page scrolled to top by site.js go()),
// pressing ArrowRight/ArrowLeft still switches the hidden hero object (hero.js:145-154) and
// fires spaceedu:show (3D model swap/fetch). Expected: keys ignored when root.dataset.page !== 'missions'.
import test from 'node:test';
import assert from 'node:assert';
import { makeEnv } from './hero__stubs.mjs';

test('ArrowRight on the Explore page must not change the hidden hero object', () => {
  const env = makeEnv({ page: 'explore', scrollY: 0 });
  env.run('data.js'); env.run('hero.js');
  const before = env.window.SpaceEdu.featured();
  const kd = env.docListeners.keydown[0];            // hero.js:145 handler (first keydown listener)
  kd({ key: 'ArrowRight', target: { tagName: 'BODY' } });
  const after = env.window.SpaceEdu.featured();
  assert.strictEqual(after, before, `hero switched from ${before} to ${after} while on page "explore"`);
});
