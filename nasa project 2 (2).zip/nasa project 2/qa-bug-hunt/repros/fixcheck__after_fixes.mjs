// Re-checks, against the FIXED code, findings whose original repro tested a stand-in instead of the changed line.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { loadSearch } from './ui__search_lib.mjs';
import { loadI18n, slice, makeStorage, src } from './ui__harness.mjs';

const plain = (x) => JSON.parse(JSON.stringify(x));          // vm arrays come from another realm
const en = loadSearch('en');
for (const lang of ['ru', 'uz']) {
  const s = loadSearch(lang);
  test(`UI-3 ${lang}: "#dust storm" returns the same kinds as English`, () => {
    const kinds = (r) => r.map((x) => x.kind).sort();
    assert.deepEqual(plain(kinds(s.search('#dust storm'))), plain(kinds(en.search('#dust storm'))));
  });
  test(`UI-11 ${lang}: timeline titles in the real search index are translated`, () => {
    const tl = s.idx().filter((x) => x.kind === 'Timeline');
    const english = tl.filter((x) => /^(Jan|Feb|Mar|Apr|May|June?|July?|Aug|Sept?|Oct|Nov|Dec)[a-z.]* /.test(x.title));
    assert.equal(english.length, 0, `${english.length}/${tl.length} still English, e.g. ${english[0] && english[0].title}`);
  });
}
test("UI-9 uz: typing qo'nish on the Glossary page shows the Lander card", () => {
  const c = loadI18n('uz');
  const cards = c.GLOSSARY.map((t) => ({ term: t.id, textContent: c.T(t.t) + c.T(t.d), hidden: false }));
  const glQ = { value: '' };
  c.glQ = glQ; c.glGrid = {}; c.$$ = () => cards; c.$ = () => ({ textContent: '' });
  vm.runInContext(slice('ui.js', 'var flat = function', "glQ.addEventListener('input'") + '\n;this.filterGl = filterGl;', c);
  glQ.value = "qo'nish"; c.filterGl();
  assert.equal(cards.find((x) => x.term === 'lander').hidden, false);
});
test('UI-8: quality held for the visit (Snd.hold) is not saved by a later voice change', () => {
  const ls = makeStorage();
  const c = { localStorage: ls, document: { addEventListener() {}, dispatchEvent() {}, hidden: false }, CustomEvent: class { constructor(t, o) { this.type = t; this.detail = o && o.detail; } }, Math, JSON, Object, Number, isFinite };
  c.window = c; vm.createContext(c);
  vm.runInContext(src('sound.js'), c);
  c.SpaceSound.hold('quality', '2d');                          // what ui.js now does when data-autoflat is set
  assert.equal(c.SpaceSound.cfg.quality, '2d', 'Settings still shows 2D for this visit');
  c.SpaceSound.set('voice', false);
  assert.equal(JSON.parse(ls.getItem('spaceedu.settings')).quality, '3d');
  c.SpaceSound.set('quality', '2d');                           // an explicit choice is saved
  assert.equal(JSON.parse(ls.getItem('spaceedu.settings')).quality, '2d');
});
