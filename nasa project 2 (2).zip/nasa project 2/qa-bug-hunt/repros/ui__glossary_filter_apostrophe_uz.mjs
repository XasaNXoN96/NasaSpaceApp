// UI-9: the glossary page filter (ui.js:196-200) compares raw lowercase text, unlike the search dialog's norm()
// which folds ‘ ’ to '. Uzbek translations use o‘ / g‘ (U+2018), but keyboards type ASCII ', so typing
// "qo'nish" on the Glossary page in UZ hides "Qo‘nish moduli" (the search dialog finds it).
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { loadI18n, slice } from './ui__harness.mjs';

const c = loadI18n('uz');
const cards = c.GLOSSARY.map((t) => ({ term: t.id, textContent: c.T(t.t) + c.T(t.d), hidden: false }));
const glQ = { value: '' }, count = { textContent: '' };
c.glQ = glQ; c.glGrid = {};
c.$$ = () => cards; c.$ = () => count;
vm.runInContext(slice('ui.js', 'function filterGl()', "glQ.addEventListener('input'") + '\n;this.filterGl = filterGl;', c);

test("uz: typing qo'nish (ASCII apostrophe) on the Glossary page shows the Lander card", () => {
  const lander = cards.find((x) => x.term === 'lander');
  assert.match(lander.textContent, /Qo‘nish/, 'precondition: UZ title uses U+2018');
  glQ.value = "qo'nish"; c.filterGl();
  assert.equal(lander.hidden, false, 'count shown: ' + count.textContent);
});
