// UI-11: search indexes timeline events with title ev[0] + ' · ' + o.title (ui.js:314) and translates it with
// T() (ui.js:326). No DICT key or RULE matches "<date> · <object>", so all 39 timeline results stay English in RU/UZ.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadI18n } from './ui__harness.mjs';

for (const lang of ['ru', 'uz']) {
  test(`${lang}: timeline result titles are translated`, () => {
    const c = loadI18n(lang, { withData: true }), D = c.SPACE_DATA;
    const titles = D.order.flatMap((id) => (D.details[id].timeline || []).map((ev) => ev[0] + ' · ' + D.objects[id].title));
    const same = titles.filter((s) => c.T(s) === s);
    assert.equal(same.length, 0, `${same.length}/${titles.length} untranslated, e.g. "${same[0]}"`);
  });
}
