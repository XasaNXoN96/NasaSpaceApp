// UI-10: closing the language menu with Escape (ui.js:147) hides it but leaves aria-expanded="true" on the
// EN/RU/UZ button, so screen readers announce a collapsed menu as expanded (outside-click path does reset it).
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { slice } from './ui__harness.mjs';

function el() { const h = {}, a = {}; return { h, a, hidden: true, textContent: '', addEventListener(t, f) { (h[t] ||= []).push(f); }, setAttribute(k, v) { a[k] = String(v); }, focus() {}, closest: () => null }; }
const btn = el(), menu = el(), docH = {};
const c = { LANG_NAME: { en: 'EN' }, lang: 'en', setLang() {}, $: (s) => (s === '#tool-lang' ? btn : menu), $$: () => [],
  document: { addEventListener(t, f) { (docH[t] ||= []).push(f); } } };
vm.createContext(c);
vm.runInContext(slice('ui.js', "var langBtn = $('#tool-lang')", '$$(\'input[name="st-l"]\')'), c);

test('Escape closes the language menu and resets aria-expanded', () => {
  btn.h.click[0]({ stopPropagation() {} });
  assert.equal(menu.hidden, false); assert.equal(btn.a['aria-expanded'], 'true');
  docH.keydown.forEach((f) => f({ key: 'Escape' }));
  assert.equal(menu.hidden, true);
  assert.equal(btn.a['aria-expanded'], 'false');
});
