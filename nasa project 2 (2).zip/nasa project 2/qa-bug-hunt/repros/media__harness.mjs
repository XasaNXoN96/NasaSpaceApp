// Shared harness: loads the real public/js/sound.js + films.js in node:vm with minimal DOM stubs.
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

export function makeCtx(counter) {
  const store = {};
  const gradient = { addColorStop() {} };
  return new Proxy(store, {
    has() { return true; },
    get(o, k) {
      if (k in o) return o[k];
      if (k === 'measureText') return () => ({ width: 10 });
      if (k === 'createImageData' || k === 'getImageData') return (w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
      if (k === 'clearRect') return () => { if (counter) counter.paints++; };
      return () => gradient;
    },
    set(o, k, v) { o[k] = v; return true; },
  });
}

function el(id) {
  const h = {};
  return {
    id, hidden: false, textContent: '', value: '0', attrs: {}, open: false,
    width: 300, height: 150, handlers: h,
    addEventListener(t, f) { (h[t] ||= []).push(f); },
    fire(t, e = {}) { (h[t] || []).forEach(f => f.call(this, Object.assign({ target: this, preventDefault() {} }, e))); },
    setAttribute(k, v) { this.attrs[k] = String(v); if (k === 'open') this.open = true; },
    getAttribute(k) { return this.attrs[k]; },
    getBoundingClientRect() { return { width: 960, height: 540 }; },
    focus() {},
  };
}

export function load({ withPlayer = true } = {}) {
  const counter = { paints: 0 };
  let now = 0; const rafQ = new Map(); let rafId = 0;
  const spoken = [];
  const els = {};
  if (withPlayer) {
    ['film', 'film-cv', 'film-sub', 'film-big', 'film-play', 'film-seek', 'film-time', 'film-snd', 'film-voice', 'film-title', 'film-src'].forEach(i => els[i] = el(i));
    const cv = els['film-cv']; cv.getContext = () => makeCtx(counter);
    const dlg = els.film; const closeBtn = el('d-close');
    dlg.querySelector = () => closeBtn; dlg.closeBtn = closeBtn;
    dlg.showModal = function () { this.open = true; };
    dlg.close = function () { this.open = false; this.fire('close'); };
  }
  const docH = {};
  const document = {
    hidden: false,
    getElementById: id => els[id] || null,
    createElement: () => ({ width: 0, height: 0, getContext: () => makeCtx(null), toDataURL: () => 'data:image/jpeg;base64,xx' }),
    querySelector: () => null,
    documentElement: { classList: { add() {}, remove() {} } },
    addEventListener(t, f) { (docH[t] ||= []).push(f); },
    dispatchEvent(e) { (docH[e.type] || []).forEach(f => f(e)); },
  };
  const store = {};
  const window = {
    document,
    localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); } },
    speechSynthesis: {
      getVoices: () => [{ lang: 'en-US', name: 'Google US English' }],
      speak: u => spoken.push(u.text), cancel() {},
    },
    devicePixelRatio: 1,
    addEventListener() {},
  };
  const sandbox = {
    window, document, localStorage: window.localStorage,
    performance: { now: () => now },
    requestAnimationFrame: f => { rafQ.set(++rafId, f); return rafId; },
    cancelAnimationFrame: id => rafQ.delete(id),
    setTimeout: () => 0, setInterval: () => 0, clearInterval() {}, clearTimeout() {},
    SpeechSynthesisUtterance: function (t) { this.text = t; },
    CustomEvent: function (type, o) { this.type = type; this.detail = o && o.detail; },
    console, Math, JSON, Object, Array, String, Number, RegExp, Uint8ClampedArray, isFinite,
  };
  sandbox.self = sandbox;
  vm.createContext(sandbox);
  for (const f of ['public/js/sound.js', 'public/js/films.js']) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
  }
  function frame(dtMs = 16) {
    now += dtMs; const q = [...rafQ.values()]; rafQ.clear(); q.forEach(f => f(now));
  }
  return { window, document, els, counter, spoken, frame, rafPending: () => rafQ.size, Films: window.SpaceFilms, Snd: window.SpaceSound };
}
