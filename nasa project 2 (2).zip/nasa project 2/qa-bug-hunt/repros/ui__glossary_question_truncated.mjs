// UI-4: the glossary round builds the question from t.d.split('. ')[0]; the Pale Blue Dot definition
// contains "Feb. 14, 1990", so the English question is cut to "...Voyager 1 took on Feb".
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { loadI18n, slice } from './ui__harness.mjs';

const c = loadI18n('en');
c.S = { ORDER: [], OBJECTS: {}, LABEL: {}, STATUS: {} };
c.askQ = () => {};
c.$ = () => ({});
vm.runInContext(slice('ui.js', "var esc = function", 'var strip = function') + '\n' +
  slice('ui.js', "var ch = $('#x-challenge')", 'var ROUND_NAME') + '\n;window.__r = function(){ startRound("glossary"); return round; };', c);

test('every glossary-round question quotes a complete first sentence', () => {
  const qs = [];
  for (let i = 0; i < 400; i++) qs.push(...c.__r().qs);
  const pbd = qs.find((q) => q.term === 'pale-blue-dot');
  assert.ok(pbd, 'pale-blue-dot question generated');
  assert.doesNotMatch(pbd.q, /took on Feb”\?$/, 'question text: ' + pbd.q);
});
