// UI-3: tag search ("#dust storm", from clicking a keyword chip) matches Glossary items by substring of the
// TRANSLATED title/text, while the tag stays English (data-tag) -> in RU/UZ the glossary hits disappear.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadSearch } from './ui__search_lib.mjs';

const en = loadSearch('en');
for (const lang of ['ru', 'uz']) {
  const s = loadSearch(lang);
  test(`${lang}: "#dust storm" returns the same items as in English`, () => {
    const kinds = (r) => r.map((x) => x.kind).sort();
    assert.deepEqual(kinds(s.search('#dust storm')), kinds(en.search('#dust storm')));
  });
}
