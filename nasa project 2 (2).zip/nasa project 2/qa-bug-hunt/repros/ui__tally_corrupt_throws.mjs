// UI-7: store.get validates only the top-level type ("a damaged or foreign value falls back to the default"),
// but count() assumes tally[key] is an array. A stored {"terms":5} or {"films":"x"} makes count() throw
// a TypeError (and renderFilms' seen.indexOf at start-up), breaking the glossary/term/achievement handlers.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { makeStorage, slice } from './ui__harness.mjs';

function load(stored) {
  const c = { localStorage: makeStorage({ 'spaceedu.tally': stored, 'spaceedu.ach': '{}' }), JSON };
  vm.createContext(c);
  vm.runInContext(slice('ui.js', 'var store = {', 'var TERM = {}') + '\n' +
    slice('ui.js', "var got = store.get('ach'", 'function award(') + '\n;this.count = count;', c);
  return c;
}

test('a damaged tally entry falls back instead of throwing', () => {
  const c = load('{"terms":5}');
  assert.doesNotThrow(() => c.count('terms', 'sol'));
});
