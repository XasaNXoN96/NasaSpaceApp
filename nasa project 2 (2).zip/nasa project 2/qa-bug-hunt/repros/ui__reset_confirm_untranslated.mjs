// UI-6: Settings > Reset calls confirm('Reset all achievements...') with the raw English string (ui.js:150).
// confirm() text is not a DOM node, so i18n.js's MutationObserver can never translate it, although the
// translation exists in I18N_STRINGS. RU/UZ visitors get an English confirmation dialog.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadI18n, src } from './ui__harness.mjs';

test('the reset confirm() text is passed through T() (translation exists for ru)', () => {
  const msg = 'Reset all achievements and progress on this device?';
  assert.notEqual(loadI18n('ru').T(msg), msg, 'precondition: RU translation exists');
  const call = src('ui.js').match(/confirm\(([^)]*)\)/)[1];
  // what the browser would show in RU: the argument evaluated as written in ui.js
  const shown = /^\s*(window\.)?T\(|TT\(/.test(call) ? 'translated' : call.replace(/^'|'$/g, '');
  assert.notEqual(shown, msg, 'confirm() receives untranslated English: ' + call);
});
