// UI-5: renderBadges (ui.js:90) formats the unlock date with toLocaleDateString('en-GB', {month:'short'}),
// which yields "Sept" for September in current ICU (Chrome, Node). i18n.js reGB only knows "Sep", so in RU/UZ
// the badge reads "Открыто 5 Sept 2026" instead of a translated date.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadI18n } from './ui__harness.mjs';

const when = new Date(2026, 8, 5).getTime();
const label = 'Unlocked ' + new Date(when).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

for (const lang of ['ru', 'uz']) {
  test(`${lang}: a badge unlocked in September gets a translated date (source "${label}")`, () => {
    const out = loadI18n(lang).T(label);
    assert.doesNotMatch(out, /Sept/, 'got: ' + out);
  });
}
