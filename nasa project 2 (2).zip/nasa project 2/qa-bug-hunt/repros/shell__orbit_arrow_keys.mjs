// Hypothesis: index.html sets enablePan:false on three@0.169.0 OrbitControls; r169's keydown handler
// returns early when enablePan === false, so arrow keys never turn the model, despite the aria-label.
import { test } from 'node:test';
import assert from 'node:assert';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const html = readFileSync(new URL('../../public/index.html', import.meta.url), 'utf8');

test('index.html configures OrbitControls with enablePan:false + keyboard listening + promises arrow keys', () => {
  assert.match(html, /three@0\.169\.0/);
  assert.match(html, /enablePan:\s*false/);
  assert.match(html, /controls\.listenToKeyEvents\(canvas\)/);
  assert.match(html, /use the arrow keys while focused, to turn it/);
});

test('r169 OrbitControls: an ArrowLeft keydown reaches the key handler when enablePan is false', async () => {
  const src = await (await fetch('https://cdn.jsdelivr.net/npm/three@0.169.0/examples/jsm/controls/OrbitControls.js')).text();
  const m = src.match(/function onKeyDown\( event \) \{[\s\S]*?\n\}/);
  assert.ok(m, 'onKeyDown found');
  const onKeyDown = vm.runInNewContext('(' + m[0] + ')');
  let handled = 0;
  const controls = { enabled: true, enablePan: false, _handleKeyDown() { handled++; } }; // as configured in index.html
  onKeyDown.call(controls, { code: 'ArrowLeft', shiftKey: true });                          // even with a modifier
  onKeyDown.call(controls, { code: 'ArrowLeft' });
  assert.strictEqual(handled, 2, 'keyboard input should reach _handleKeyDown so the model can turn');
});
