// Hypothesis: when WebGL is unavailable, the start-up branch (index.html:649) only announces the failure;
// unlike the 2D-setting and init()-throws branches, it never hides canvas.gl, which keeps tabindex=0 and
// role=img "3D model ... use the arrow keys" while invisible (opacity 0) -> a dead tab stop for keyboard/SR users.
import { test } from 'node:test';
import assert from 'node:assert';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const html = readFileSync(new URL('../../public/index.html', import.meta.url), 'utf8');
const i = html.indexOf('function webglAvailable()'), j = html.indexOf('function init()', i);
const code = html.slice(i, j);
assert.match(html, /<canvas class="gl" tabindex="0" role="img"/);

function run(flat) {
  const canvas = { hidden: false };
  const cls = new Set(flat ? ['flat'] : []);
  const ctx = {
    root: { classList: { contains: c => cls.has(c) } },
    canvas, stage: { classList: { remove() {} } },
    document: { createElement: () => ({ getContext: () => null }), dispatchEvent() {} },   // no WebGL
    Event: class { constructor(t) { this.type = t; } },
    init() { throw new Error('should not run'); }
  };
  vm.runInNewContext(code, ctx);
  return canvas;
}
test('2D setting hides the canvas (control)', () => assert.strictEqual(run(true).hidden, true));
test('no WebGL: the invisible 3D canvas is removed from the tab order / a11y tree', () =>
  assert.strictEqual(run(false).hidden, true, 'canvas.gl stays focusable and announced with no 3D behind it'));
