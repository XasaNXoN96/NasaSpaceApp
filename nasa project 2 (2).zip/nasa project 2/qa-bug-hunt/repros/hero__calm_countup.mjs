// Hypothesis: with the in-site "reduced animation" setting (html.calm, set by index.html:43), and the OS
// reduced-motion query false, sections.js:10 computes reduce=false (it ignores .calm, unlike hero.js:4 and
// site.js:6), so the stats count-up animation (sections.js:114-133) and reveal-on-scroll still run.
// Expected: no count-up IntersectionObservers / no 'reveal-on' class when html.calm is set.
import test from 'node:test';
import assert from 'node:assert';
import { makeEnv, el } from './hero__stubs.mjs';

test('html.calm must disable the sections.js count-up and reveal animations', () => {
  const env = makeEnv({ calm: true, rmMedia: false });
  const stats = ['57', '49', '83'].map((t, i) => el({ textContent: t, dataset: i < 2 ? { count: ['apollo', 'voyager'][i] } : { to: t } }));
  const qsa = env.document.querySelectorAll;
  env.document.querySelectorAll = s => s === '.x-stats b' ? stats : qsa(s);
  env.run('data.js'); env.run('hero.js'); env.run('photos.js'); env.run('sections.js');
  const countIOs = env.ioLog.filter(io => io.targets.some(t => stats.includes(t)));
  assert.strictEqual(env.root.classList.contains('reveal-on'), false, 'reveal-on added despite html.calm');
  assert.strictEqual(countIOs.length, 0, `${countIOs.length} count-up observers armed despite html.calm`);
});
