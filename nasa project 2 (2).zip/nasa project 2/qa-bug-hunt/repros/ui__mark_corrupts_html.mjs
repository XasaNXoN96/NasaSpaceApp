// UI-2: mark() highlights each query word sequentially on already-marked HTML, so a later word that is a
// substring of "mark" (ma, mar, ar, rk...) or of an entity (amp, quot, lt, gt) is wrapped INSIDE tags/entities.
import test from 'node:test';
import assert from 'node:assert/strict';
import { loadSearch } from './ui__search_lib.mjs';

const { mark } = loadSearch('en');

test('typing "spirit ma" (on the way to "spirit mars") keeps the <mark> tags intact', () => {
  const out = mark('Spirit on Mars', 'spirit ma');
  assert.equal(out, '<mark>Spirit</mark> on <mark>Ma</mark>rs');
});
test('query "amp" does not break the &amp; entity', () => {
  assert.equal(mark('R&D lab', 'amp'), 'R&amp;D lab');
});
