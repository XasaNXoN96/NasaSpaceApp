// UI-8: on a data-saver/cellular visit, ui.js:156 sets cfg.quality = '2d' "in memory only". cfg is the live
// object of sound.js, and Snd.set() saves the WHOLE cfg. So any later unrelated setting change (sound toggle,
// volume slider, voice checkbox) persists quality:'2d'; the next visit (even on Wi-Fi) is forced flat via
// index.html's st.quality === '2d' branch and never offers "Load 3D" again (data-autoflat is not set).
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { makeStorage, src } from './ui__harness.mjs';

test('an auto-chosen 2D mode is not saved when the visitor only changes the voice setting', () => {
  const ls = makeStorage();                                    // first visit: nothing saved
  const c = { localStorage: ls, document: { addEventListener() {}, dispatchEvent() {}, hidden: false }, CustomEvent: class { constructor(t, o) { this.type = t; this.detail = o && o.detail; } }, Math, JSON, Object, Number, isFinite };
  c.window = c; vm.createContext(c);
  vm.runInContext(src('sound.js'), c, { filename: 'sound.js' });
  const cfg = c.SpaceSound.cfg;
  cfg.quality = '2d';                                          // exactly what ui.js:156 does when data-autoflat is set
  c.SpaceSound.set('voice', false);                            // Settings > voice checkbox (ui.js:125)
  const saved = JSON.parse(ls.getItem('spaceedu.settings'));
  assert.notEqual(saved.quality, '2d', 'saved settings: ' + ls.getItem('spaceedu.settings'));
});
