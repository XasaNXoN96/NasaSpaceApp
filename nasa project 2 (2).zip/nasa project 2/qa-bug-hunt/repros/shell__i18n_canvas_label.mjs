// Hypothesis: showModel() (index.html:1044) rewrites canvas.gl's aria-label to
// "3D model of <NAME>. Drag, or use the arrow keys..." ; i18n translates attributes only by exact DICT hit,
// and only the Perseverance variant exists, so in RU/UZ the label stays English for the other 5 objects.
import { test } from 'node:test';
import assert from 'node:assert';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const pub = new URL('../../public/', import.meta.url);
const html = readFileSync(new URL('index.html', pub), 'utf8');
assert.match(html, /canvas\.setAttribute\('aria-label', `3D model of \$\{NAMES\[id\]\}\. Drag, or use the arrow keys while focused, to turn it\.`\)/);
const NAMES = ['Perseverance', 'the Apollo 11 laser retroreflector', 'Voyager 1', 'Sojourner', 'Spirit', 'Opportunity'];

function loadT(lang) {
  const body = { nodeType: 1, tagName: 'BODY', getAttribute: () => null };
  const ctx = { localStorage: { getItem: () => lang }, NodeFilter: { SHOW_ELEMENT: 1, SHOW_TEXT: 4, FILTER_REJECT: 2, FILTER_ACCEPT: 1 },
    document: { documentElement: {}, body, title: '', createTreeWalker: () => ({ nextNode: () => null }), querySelector: () => null },
    MutationObserver: class { observe() {} } };
  ctx.window = ctx; vm.createContext(ctx);
  for (const f of ['js/i18n-strings.js', 'js/i18n.js']) vm.runInContext(readFileSync(new URL(f, pub), 'utf8'), ctx);
  return ctx.T;
}
for (const lang of ['ru', 'uz']) {
  test(`${lang}: every 3D canvas label is translated`, () => {
    const T = loadT(lang);
    const untranslated = NAMES.map(n => `3D model of ${n}. Drag, or use the arrow keys while focused, to turn it.`).filter(s => T(s) === s);
    assert.deepStrictEqual(untranslated, []);
  });
}
