// Minimal DOM stubs shared by hero__*.mjs repros (read-only harness; loads real public/js files via node:vm)
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
export const PUB = path.resolve(here, '..', '..', 'public');

function classList() {
  const s = new Set();
  return { add: (...c) => c.forEach(x => s.add(x)), remove: (...c) => c.forEach(x => s.delete(x)),
    contains: c => s.has(c), toggle: (c, on) => { (on ?? !s.has(c)) ? s.add(c) : s.delete(c); } };
}
export function el(extra = {}) {
  const listeners = {};
  const e = { dataset: {}, style: { setProperty() {} }, classList: classList(), textContent: '', innerHTML: '',
    focusCalls: 0, attrs: {}, tagName: 'DIV', listeners,
    setAttribute(k, v) { this.attrs[k] = v; }, getAttribute(k) { return this.attrs[k]; }, removeAttribute(k) { delete this.attrs[k]; },
    addEventListener(t, f) { (listeners[t] ||= []).push(f); },
    dispatch(t, ev = {}) { (listeners[t] || []).forEach(f => f.call(e, Object.assign({ target: e }, ev))); },
    focus() { this.focusCalls++; }, contains: () => false, closest: () => null, querySelector: () => el(), querySelectorAll: () => [],
    animate() {}, scrollIntoView() {}, scrollTo() {}, getBoundingClientRect: () => ({ left: 0, right: 0, top: 0, bottom: 0 }),
    showModal() { this.open = true; }, close() { this.open = false; }, ...extra };
  return e;
}
export function makeEnv({ calm = false, page, scrollY = 0, rmMedia = false } = {}) {
  const cache = {};
  const root = el(); if (calm) root.classList.add('calm'); if (page) root.dataset.page = page;
  const ids = ['apollo', 'voyager', 'sojourner', 'spirit', 'opportunity', 'perseverance'];
  const layers = ids.map(id => el({ dataset: { object: id, bg: 'https://x/' + id + '.jpg' } }));
  const picks = ids.map(id => el({ dataset: { object: id }, tagName: 'BUTTON' }));
  const docListeners = {};
  const rafQ = [];
  const ioLog = [];
  const document = {
    documentElement: root, title: '', activeElement: null,
    querySelector: s => (s === 'dialog[open]' ? null : (cache[s] ||= el())),
    querySelectorAll: s => s === '.sky .layer' ? layers : s === '.pick' ? picks : [],
    getElementById: id => (cache['#' + id] ||= el()),
    addEventListener: (t, f) => (docListeners[t] ||= []).push(f),
    dispatchEvent: () => true,
  };
  class IntersectionObserver { constructor(cb, o) { this.cb = cb; ioLog.push(this); this.targets = []; }
    observe(t) { this.targets.push(t); } unobserve() {} disconnect() {} }
  const window = { scrollY, innerHeight: 800, matchMedia: () => ({ matches: rmMedia }), addEventListener() {},
    IntersectionObserver, document };
  const ctx = { window, document, navigator: {}, IntersectionObserver, matchMedia: window.matchMedia,
    requestAnimationFrame: f => rafQ.push(f), setTimeout: () => 0, performance: { now: () => 0 },
    CustomEvent: class { constructor(t, o) { this.type = t; Object.assign(this, o); } }, console, Date, Math, String, Array, Object, JSON };
  window.window = window;
  vm.createContext(ctx);
  // make window properties visible as globals (classic scripts)
  const run = f => { vm.runInContext(fs.readFileSync(path.join(PUB, 'js', f), 'utf8') + '\n;Object.assign(window, {PHOTOS: typeof PHOTOS!=="undefined"?PHOTOS:window.PHOTOS});', ctx, { filename: f }); };
  return { ctx, window, document, root, picks, layers, docListeners, rafQ, ioLog, cache, run };
}
