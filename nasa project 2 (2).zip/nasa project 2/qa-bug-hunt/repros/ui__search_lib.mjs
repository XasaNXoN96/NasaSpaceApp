// Loads the REAL search code of ui.js (lines `var sDlg = ...` up to `function renderResults`) into a vm
// context that already holds the real i18n + data + learn-data for `lang`.
import vm from 'node:vm';
import { loadI18n, slice } from './ui__harness.mjs';

export function loadSearch(lang = 'en') {
  const c = loadI18n(lang, { withData: true });
  if (lang === 'en') c.T = (s) => s;
  const D = c.SPACE_DATA;
  c.S = { ORDER: D.order, OBJECTS: D.objects, DETAILS: D.details };
  // strip(): ui.js uses a detached div's textContent; approximate: drop tags, decode the few entities used
  c.strip = (h) => String(h).replace(/<[^>]*>/g, '').replace(/&ndash;/g, '–').replace(/&mdash;/g, '—').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');
  c.$ = () => ({}); c.$$ = () => [];       // no page sections in node (section items are skipped)
  c.openObject = c.closeAll = c.showTerm = () => {};
  c.location = { hash: '' };
  const escLine = slice('ui.js', 'var esc = function', 'var strip = function');   // the real esc() from ui.js:8
  const code = slice('ui.js', 'var sDlg = $(', 'function renderResults()');
  vm.runInContext(escLine + '\n' + code + '\n;window.__s = { search: search, mark: mark, snippet: snippet, norm: norm, build: buildIndex, idx: function(){ return index; }, ALIAS: ALIAS };', c, { filename: 'ui.js(search slice)' });
  c.__s.build();
  return c.__s;
}
