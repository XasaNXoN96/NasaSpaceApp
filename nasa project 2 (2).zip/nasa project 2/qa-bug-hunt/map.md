# Map — SpaceEdu (static site, no build, no tests, not a git repo)
Served from public/ (Firebase Hosting, SPA rewrite ** -> /index.html). Local: python -m http.server 8781 --directory public
Entry: public/index.html (1325 lines: markup, inline start-up script, importmap, inline 3D <script type=module>)
Scripts load in order (classic, globals via window.* and top-level var):
 i18n-strings -> i18n -> data (window.SPACE_DATA) -> hero -> photos (PHOTOS) -> sections -> sources
 -> voyager-ephemeris (V) -> astro (Astro) -> parts (MER_PARTS, SPACE_PARTS) -> site (FACTS)
 -> learn-data (GLOSSARY, TAGS, QUESTIONS) -> sound (window.SpaceSound) -> films (window.SpaceFilms)
 -> ui -> present -> inline module (3D viewer)
Styles: public/style3.css (5656 lines)
External: NASA 3D models, NASA photos, live Perseverance data (network), three.js via importmap
