| partition | files | LOC | risk | depth | status |
|---|---|---|---|---|---|
| shell | index.html | 1325 | high (entry, inline scripts, 3D module) | deep | done (4 Confirmed-logic: 1 Medium, 3 Low) |
| live-data | site.js, astro.js, voyager-ephemeris.js, data.js, sources.js, parts.js | ~1130 | high (time/date math, network, live data) | deep | done (3 Confirmed: 1 Medium, 2 Low; 1 Suspected Low) |
| ui-i18n | ui.js, i18n.js, i18n-strings.js, learn-data.js, present.js | ~860 | high (state, persistence, search, quiz, i18n) | deep | done (11 Confirmed + UI-12 confirmed in browser; 3 Medium) |
| media | films.js, sound.js | ~1220 | medium (timers, audio, async) | deep | done (4 Confirmed: 1 Medium, 3 Low) |
| hero-sections | hero.js, sections.js, photos.js | ~630 | medium | deep | done (2 Confirmed, 1 Suspected, all Low) |
| styles | style3.css | 5656 | low | light (runtime layout checks only) | done — no page-level horizontal overflow at 375px; off-edge .pick items sit in a scroll strip |
