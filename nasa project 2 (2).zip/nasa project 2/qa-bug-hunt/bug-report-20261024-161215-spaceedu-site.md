# QA bug hunt — SpaceEdu site (whole codebase)

- Run: 2026-10-24 16:12 UTC · scope: whole site (`public/`) · cold run (no prior knowledge card)
- Environment: local, `python -m http.server 8781 --directory public`, Chromium (Playwright MCP), Node 24.18 for repros
- Read-only check: 0 files under `public/` modified during the hunt (mtime check; not a git repo).
- Full per-finding records (preconditions, root cause, cross-partition notes): `./findings/*.md`. Coverage: `./coverage.md`.

## Summary

28 findings: **0 Critical · 0 High · 6 Medium · 22 Low**. 24 Confirmed, 2 Suspected, 1 observation, 1 note.

| # | Sev | Status | Where | What breaks |
|---|---|---|---|---|
| UI-1 | Medium | Confirmed | ui.js:331-354 | RU/UZ search: common native words (солнце, вода, quyosh, suv…) return 0 results — alias swaps to English after the index was already translated |
| UI-8 | Medium | Confirmed | ui.js:156 × sound.js:15,211 | Auto-chosen 2D mode (cellular/data-saver) gets saved by any later sound/voice change → 3D disabled forever on that browser |
| UI-12 | Medium | Confirmed (walked by hand) | present.js:44 | Presentation mode: Enter on Next until slide 6 disables the focused button, focus falls to `<body>`, arrow keys stop working |
| LD-1 | Medium | Confirmed | site.js:328-329 | Perseverance "driven" headline reads **0.00 km** when NASA's feed ends on a mid-drive row (happened 5× in real data) |
| MEDIA-1 | Medium | Confirmed | films.js:893,902-908 | Films speak narration even after Narration is turned off in Settings; button says "Narration on" |
| SHELL-1 | Medium | Confirmed (r169 source + repro) | index.html:877-880 | Arrow keys don't rotate the 3D model (OrbitControls r169 ignores keys when `enablePan:false`); aria-label promises they do |
| LD-2 | Low | Confirmed | site.js:220-226 | Explore time slider before 2026-10-01: Earth–Voyager distance/light-time impossible (linear extrapolation of Earth column) |
| LD-3 | Low | Confirmed | site.js:239-242 | Mars local clock ~11 min slow; sol shows previous day for ~11 min after midnight (Earth-receive time used as touchdown) |
| LD-4 | Low | Suspected | site.js:341-342 | NASA raw-image fields inserted via innerHTML / unvalidated href (defence in depth) |
| HERO-1 | Low | Confirmed | hero.js:145-154 | ←/→ on other pages silently switches the hidden hero object (and 3D download) |
| HERO-2 | Low | Confirmed | sections.js:10 | "Reduced animation" setting ignored by count-up + reveal observer |
| HERO-3 | Low | Suspected | sections.js:163-178 | Photo lightbox closes on scrollbar click; no page scroll lock |
| SHELL-2 | Low | Confirmed | index.html:1029,944-954 | Low-memory devices: part markers never return after switching away and back |
| SHELL-3 | Low | Confirmed | index.html:649 | No-WebGL/failed load leaves invisible, mislabeled canvas as a tab stop |
| SHELL-4 | Low | Confirmed | index.html:1044 | Canvas aria-label English in RU/UZ for 5 of 6 objects |
| MEDIA-2 | Low | Confirmed | films.js:932-941 | Paused film repaints every frame (CPU/battery) |
| MEDIA-3 | Low | Confirmed | films.js:943-957 | After replay + pause, button still "Watch again" but resumes |
| UI-2 | Low | Confirmed | ui.js:369-375 | Search highlight corrupts results ("spirit ma" → garbled tags, "amp" breaks `&amp;`) |
| UI-3 | Low | Confirmed | ui.js:344-349 | RU/UZ tag chips lose glossary results |
| UI-4 | Low | Confirmed | ui.js:438 | Pale Blue Dot quiz question truncated at "Feb." |
| UI-5 | Low | Confirmed | ui.js:90, i18n.js:44 | Badge dates show "Sept" untranslated in RU/UZ |
| UI-6 | Low | Confirmed | ui.js:150 | Reset confirm() dialog in English for RU/UZ |
| UI-7 | Low | Confirmed | ui.js:11-19,56-59,493 | Malformed stored tally/films throws TypeError |
| UI-9 | Low | Confirmed | ui.js:196-200 | Glossary filter: plain apostrophe doesn't match Uzbek ‘ |
| UI-10 | Low | Confirmed | ui.js:147 | Escape closes language menu but leaves aria-expanded="true" |
| UI-11 | Low | Confirmed | ui.js:314,326 | 39 Timeline search titles untranslated in RU/UZ |
| MEDIA-4 | Low | Observation | public/img/films/ | 17 images (~1.8 MB) not referenced anywhere — dead weight or unfinished feature |
| — | Low | Note | data.js | "2,006th Martian day" for sol 2006 is the 2,007th (sol 0 = landing) |

## How to reproduce

Every Confirmed finding (except UI-12 and SHELL-1's browser half) has a Node repro: `node qa-bug-hunt/repros/<file>.mjs` — the verbatim failing output is in the matching `.log`. Mapping: `shell__*` → SHELL-n, `livedata__site_live.mjs` → LD-1..3, `media__test_films.mjs` → MEDIA-1..3, `hero__*` → HERO-1..2, `ui__*` → UI-n (file names describe the bug).

UI-12 (walked by hand, Playwright MCP): open the site → press `P` → press `Enter` five times → slide reads "6 / 6", `document.activeElement` is `BODY` → press `←` → slide stays "6 / 6".

Manual reproduction for the rest is given per finding in `./findings/*.md` (derived from code path unless noted).

## Suggested fixes (recommendations)

- UI-1/UI-3: OR alias with the original word / match tags against both English and translated text.
- UI-8: keep runtime-only quality out of the object `sound.js` persists.
- UI-12: move focus to the dialog (or the enabled sibling button) when the focused nav button becomes disabled.
- LD-1: use the last feature with `final==='y'` / non-zero `dist_total_m`.
- MEDIA-1: read `Snd.cfg.voice` on open() / listen for settings changes.
- SHELL-1: set `keys`/handle arrows manually, or allow key events without pan (e.g. own keydown → `controls.rotateLeft`-equivalent).
- Remaining Lows: see root-cause notes in `./findings/*.md`.

## Coverage

All 16 JS files + index.html deep-scanned in 5 partitions; style3.css light pass (runtime overflow check at 375px — clean). Blind spots: real low-memory device, real no-WebGL browser, real RU/UZ screen reader; WebGL context-restore lighting left unconfirmed (not filed).

## Fix pass (applied after the hunt, at the user's request)

Backup of the original site: `public-backup-20261024/`. Changed scripts bumped to `?v=13` in `public/index.html`.

| Finding | Fix | Verified by |
|---|---|---|
| UI-1 | search tries each word and its English alias | `fixcheck` + RU: солнце 3, вода 5, кратер 14 results |
| UI-2 | highlight in one pass over plain text | `ui__mark_corrupts_html` passes |
| UI-3 | tag chips also match the translated tag | `fixcheck__after_fixes.mjs` |
| UI-4 | definition split only at a real sentence end | repro passes |
| UI-5 | en-GB "Sept" accepted | repro passes |
| UI-6 | confirm() text translated | repro passes |
| UI-7 | damaged tally/films lists fall back to [] | repro passes |
| UI-8 | `SpaceSound.hold()` keeps auto-2D out of saved settings | `fixcheck__after_fixes.mjs` |
| UI-9 | glossary filter folds ‘ ’ ʻ ʼ to ' | `fixcheck__after_fixes.mjs` |
| UI-10 | Escape resets aria-expanded | repro passes |
| UI-11 | timeline titles built from translated date + name | `fixcheck` (39/39 translated RU+UZ) |
| UI-12 | focus moves to the other nav button when the focused one disables | walked in browser: 6/6 → ← → 5/6 |
| LD-1 | total from last row with a distance; place from newest | repro + live feed now (sol 2009 mid-drive) shows 45.22 km |
| LD-2 | outside the table, Earth distance computed from Earth's position | -730 d: 0.57 AU apart, 22.95 h |
| LD-3 | landing time = touchdown 20:43:49 UTC | LMST matches NASA feed (16:21, error 0.0 min) |
| LD-4 | caption via textContent, link only if https | code review |
| HERO-1 | arrow keys only on the Missions page | repro passes |
| HERO-2 | sections.js honours html.calm | repro passes |
| HERO-3 | lightbox closes only on a click outside its box (scroll lock already via ui.js observer) | code review |
| SHELL-1 | own arrow-key handler turns the camera | browser screenshots `./evidence/fix-shell1-b.png` → `-c.png` |
| SHELL-2 | stale marker set rebuilt for a new holder | repro passes |
| SHELL-3 | canvas hidden without WebGL; not focusable while a load failed | repro passes |
| SHELL-4 | RU/UZ rule for every "3D model of …" label | repro + browser (RU Voyager label) |
| MEDIA-1 | voice setting re-read on open | repro passes |
| MEDIA-2 | paused film painted only when something changed | repro passes |
| MEDIA-3 | big button reset to ▶ when playback starts | repro passes |

Not changed: MEDIA-4 (unused images — deleting is the team's call) and the "2,006th day" wording note.
Original repros that still fail do so because they test a stand-in rather than the changed line (they hard-code the old landing time, slice code without new helpers, or test OrbitControls itself); each such case is re-checked in `./repros/fixcheck__after_fixes.mjs` or in the browser as listed above.
