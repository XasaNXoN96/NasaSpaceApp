# Findings — partition: live-data (site.js, astro.js, voyager-ephemeris.js, data.js, sources.js, parts.js)

## LD-1 · public/js/site.js:328-329 · Perseverance "Driven on Mars" shows 0.00 km
- Precondition: NASA's M20_waypoints.json ends on a mid-drive ("final":"m") or interpolated ("i") row. These rows carry dist_km=0 / dist_total_m=0 (153 such rows in today's live file; 5 times a sol's batch ended on one, e.g. sols 350, 351, 358, 380, 1896).
- Expected: total distance from the last end-of-drive row (e.g. 42.51 km). Actual: big number "0.00 km" next to "Sol 1896 · 135.6 m"; code blindly takes `d.features[d.features.length - 1]`.
- Status: Confirmed. Severity: Medium (the site's headline live figure for the one active rover reads zero; it happens whenever NASA appends a mid-drive fix first).
- Cross-partition: none. Fixture = real rows from the live feed (fetched 2026-10-24).
- Repro: qa-bug-hunt/repros/livedata__site_live.mjs (test 1) → `actual: '0.00 km'`; log livedata__site_live.log
- Root cause: no filter on `properties.final === 'y'` / non-zero dist_km before reading the last feature.

## LD-2 · public/js/site.js:220-226 (with voyager-ephemeris.js rows starting at day 273) · Voyager 1 Earth distance wrong when time-travelling back
- Precondition: Explore map time slider set to any negative offset reaching before 2026-10-01 (table starts at day 273; slider allows -730 d).
- Expected: Earth–Voyager distance within ~1 AU of Sun–Voyager distance. Actual: linear extrapolation of the first 5-day segment of the *Earth* column (which includes Earth's orbital motion, 0.113 AU/5 d vs 0.049 for the Sun column): -300 d → earth 165.97 AU vs sun 169.21 (diff -3.25 AU); -730 d → 156.27 vs 165.02 (-8.75 AU), signal "21 h 39 min" instead of ~22.9 h. Shown in #x-vgk, #x-vgl and the map tooltip.
- Status: Confirmed. Severity: Low (only behind the time slider, but the numbers are physically impossible on an educational page). Same drift will hit the live card after the table ends 2028-12-29.
- Repro: livedata__site_live.mjs (test 2) → `|earthAU - sunAU| = 3.25 AU`
- Root cause: "extrapolates gently past the ends" is only valid for the near-linear Sun column; table covers only from 2026-10-01 forward.

## LD-3 · public/js/site.js:239-242 · Sol clock runs ~11 min late (sol number rolls over late)
- Precondition: any time. M20_LAND = 20:55 UTC is the Earth-received time; the 0.662-sol (15:53 LMST) offset belongs to touchdown (~20:44 UTC spacecraft time).
- Expected: LMST at NASA raw image 2026-10-24T08:40:07Z = 16:21 (feed `date_taken_mars` "Sol-02018M16:21:24"). Actual: code gives 16:10 (-10.8 min). Sol number itself correct (2018) except in the ~11 min after each Jezero midnight, where "Mission day now (sol)" shows the previous sol.
- Status: Confirmed. Severity: Low (off by one sol for ~11 min per sol).
- Repro: livedata__site_live.mjs (test 4) → `sol clock off by -10.8 min`
- Root cause: mixing ERT landing time with SCET-based local time.

## LD-4 · public/js/site.js:341-342 · Third-party feed strings injected with innerHTML
- Precondition: raw-images feed returns `credit`/`camera.instrument`/`sol` containing markup. Expected: text. Actual: figcaption built via innerHTML from feed fields (also `a.href = im.link` unchecked).
- Status: Suspected (code reading; NASA feed is trusted in practice, not reproduced). Severity: Low (defence in depth).
- Cross-partition: none. Manual: stub the feed response in DevTools (Overrides) with credit "<img src=x onerror=alert(1)>", open #live.

## Checked, no bug
- astro.js: all 8 JPL Standish element rows + rates match Table 1; Kepler solver/rotation correct; Meeus ch.47 distance terms all 31 coefficients match.
- Voyager table: today 172.14 AU Sun / 172.70 AU Earth, light-time 23 h 56 min, speed 16.88 km/s (60,800 km/h); crosses 1 light-day 2026-11-19 03:00 UTC = Nov 18 US time, consistent with data.js. (Brief's ~170 AU / 23.5 h estimate is low; table agrees with NASA's light-day date.) V1_LON 256.78° plausible.
- data.js vs live feed: record sol 2006 = Oct 11, 2026 (code's sol formula), first waypoint >45.16 km is sol 2006, marathon sol 1890 = June 14 (caption "June 13, a day before" correct), lastKnown fallback (45.22 km, sol 2009, 18.44N 77.23E) equals current feed tail. Status codes consistent across data.js/site.js CARDS/hero.js. Spirit/Opportunity/Sojourner dates, distances, durations consistent.
- sources.js CITE array lengths match every data.js list (stats/found/status/timeline) for all six objects.
- since()/hms()/km-h conversions, fetch error paths (non-ok → lastKnown; refresh keeps old figures), raw-image date parsing (feed has no trailing Z), parts.js `p.d[id] || p.d` fallback.
