# Partition: shell (public/index.html)

## SHELL-1 · public/index.html:877-880 (+ canvas aria-label :116 of markup, :1044)
- Precondition: 3D viewer running; keyboard user Tabs to canvas.gl and presses arrow keys (aria-label says "use the arrow keys while focused, to turn it").
- Expected: model turns. Actual: nothing happens. three@0.169.0 OrbitControls `onKeyDown` returns early when `enablePan === false` (OrbitControls.js r169 line ~1343), and index.html sets `enablePan:false`; even Shift/Ctrl+arrow (r169's rotate chord) is dropped. `controls.keyRotateSpeed` is not an r169 property (no effect).
- Status: Confirmed (logic) — browser check recommended: focus canvas, press ←/→ and Shift+←.
- Severity: Medium — the only non-pointer way to rotate is advertised but dead; keyboard/SR users cannot use the 3D control.
- Cross-partition: none.
- Repro: qa-bug-hunt/repros/shell__orbit_arrow_keys.mjs (.log): `0 !== 2` handled keydowns.
- Root cause: relies on pre-r155 OrbitControls key semantics; needs own keydown handler (rotateLeft/Up) or enablePan with key-only path.

## SHELL-2 · public/index.html:1029 + :944-954 + :1107-1108
- Precondition: low-memory device (`navigator.deviceMemory <= 2`); show Spirit, point at it (markers created), switch to Perseverance (release() disposes MER holder), switch back to Spirit.
- Expected: part markers/tooltips on the re-downloaded Spirit. Actual: `partsFor` returns the cached `markerSets.get('spirit')` whose group is still attached to the old, disposed, off-scene holder; markers never render on the new model (raycast tooltip still works off cached positions). release() also disposes those sprites' materials.
- Status: Confirmed (logic) — browser: DevTools emulate deviceMemory unsupported; manual on a ≤2 GB device or override `navigator.deviceMemory` before load.
- Severity: Low — feature loss limited to low-memory devices.
- Cross-partition: none. Repro: qa-bug-hunt/repros/shell__lowmem_markers.mjs (.log): group.parent !== holder2.
- Root cause: release() doesn't evict markerSets entries (or partsFor doesn't check `set.group.parent === holder`).

## SHELL-3 · public/index.html:649 (also failure path :1017-1022)
- Precondition: browser without WebGL (or a model download fails offline).
- Expected: invisible 3D canvas removed from tab order/a11y tree, as in the 2D branch (:645) and init()-throws branch (:648). Actual: `else announce3dFail();` leaves canvas.gl visible-to-AT: tabindex=0, role=img "3D model of Perseverance. Drag, or use the arrow keys…" at opacity 0 — a dead, mislabeled tab stop over the photo.
- Status: Confirmed (logic) — browser: launch Chrome with --disable-webgl, Tab from the header into the hero.
- Severity: Low — confusing/false announcement, extra invisible focus stop; doesn't block other content.
- Repro: qa-bug-hunt/repros/shell__nowebgl_canvas_focusable.mjs (.log): control passes, no-WebGL case `canvas.hidden` false.
- Root cause: missing `canvas.hidden = true` in the no-WebGL branch (and in showModel's catch when nothing was ever shown).

## SHELL-4 · public/index.html:1044 vs js/i18n-strings.js
- Precondition: language RU or UZ; pick any object other than Perseverance.
- Expected: translated canvas aria-label. Actual: label stays English for Apollo, Voyager 1, Sojourner, Spirit, Opportunity — i18n translates attributes only by exact DICT key and only the Perseverance string exists (no RULE for "3D model of …").
- Status: Confirmed. Severity: Low — screen-reader users in RU/UZ hear English for the main control.
- Cross-partition: i18n partition owns DICT/RULES. Repro: qa-bug-hunt/repros/shell__i18n_canvas_label.mjs (.log): 5 untranslated labels per language.
- Root cause: dynamic template string with no matching RULE in i18n.js.
