# Findings: media partition (public/js/films.js, public/js/sound.js)

MEDIA-1 · public/js/films.js:893 (voiceOn read once at load), :902-908 say(), ui.js:125 (#st-voice → Snd.set('voice'))
- Pre: user turns Narration OFF in Settings, then opens a film and presses Play → expected: no speech, film button reads "Narration off" → actual: the scene line is spoken via speechSynthesis and the button still reads "Narration on".
- Status: Confirmed. Severity: Medium (a saved user preference is silently ignored; audible speech the user disabled, e.g. in class).
- Cross-partition: assumes Settings' #st-voice is the only other writer of cfg.voice (ui.js:125, seen by grep).
- Repro: qa-bug-hunt/repros/media__test_films.mjs ("Narration switched off in Settings"); log media__test_films.log: spoken = ['July 4, 1997. Mars Pathfinder lands…'].
- Root cause: films.js caches `voiceOn = Snd.cfg.voice` at script load and never re-reads it (no listener for 'spaceedu:settings', open() doesn't resync). Reverse direction (film button → cfg) works.

MEDIA-2 · public/js/films.js:932-941 loop(), :967 open()
- Pre: open any film and leave it paused (its initial state) → expected: static frame, ~0 repaints → actual: the full canvas scene (globe strips, gradients, grain, vignette) is repainted on every animation frame, 60/s, as long as the dialog is open.
- Status: Confirmed. Severity: Low (perf/battery on student laptops/phones; no functional break).
- Repro: media__test_films.mjs ("paused player keeps repainting"); log: "paused film painted 60 full frames in 1 s".
- Root cause: rAF loop is re-armed unconditionally and render() runs whether or not `playing`; nothing changes while paused except on seek/resize.

MEDIA-3 · public/js/films.js:943-946 end(), :947-957 setPlaying()
- Pre: watch a film to the end (big button becomes ↻ "Watch again"), click it, then pause mid-film → expected: big button shows ▶ "Play film" → actual: still ↻ with aria-label "Watch again", but clicking it resumes from the paused point (does not restart).
- Status: Confirmed. Severity: Low (misleading icon + screen-reader label).
- Repro: media__test_films.mjs ("after a film ends and is replayed"); log: aria-label === 'Watch again'.
- Root cause: end() rewrites big's text/label; only open() resets them, setPlaying(true) never does.

MEDIA-4 · public/img/films/ (17 JPGs, ~1.8 MB: pia00024 … pia26147)
- Pre: grep for "img/films", "films/" and each pia id in public/**/*.js|html|css|json → expected: files referenced → actual: no local reference anywhere; films.js draws every frame procedurally (its own header says "no video file and no photograph"), and other NASA images load from assets.science.nasa.gov.
- Status: Confirmed (static grep, no repro needed). Severity: Low (dead deployed weight / possibly an unfinished feature; no missing-file errors — the reverse risk does not exist).
- Root cause: orphaned assets; the brief's assumption that films.js uses them is not borne out.
