# Partition: hero-sections (hero.js, sections.js, photos.js)

## HERO-1 · public/js/hero.js:145-154
- Precondition: user is on a non-Missions page (Explore/Learn/Compare/Glossary; site.js go() scrolls to top, so scrollY=0) and presses ← / → / [ / ] with focus on a non-input element.
- Expected: keys ignored (hero is hidden on that page). Actual: show(step(±1)) runs: the hidden hero switches object, `spaceedu:show` fires (3D viewer swaps/fetches a model; sources.js reacts), the announcer text changes; returning to Missions shows a different spacecraft than the user left.
- Status: Confirmed · Severity: Low (invisible state change + wasted model download; no data loss).
- Cross-partition: assumes site.js go() keeps root.dataset.page in sync (site.js:58) and that no other page binds ←/→ itself.
- Repro: qa-bug-hunt/repros/hero__arrowkeys_hidden_page.mjs (.log) — fails: "hero switched from perseverance to apollo while on page "explore"".
- Root cause: the guard only checks scrollY/menu/dialog/inputs, never `root.dataset.page === 'missions'` (show() itself already checks page for the title at hero.js:100).

## HERO-2 · public/js/sections.js:10 (effects at :61, :114-133)
- Precondition: visitor chose "reduced animation" in Settings (index.html:43 adds html.calm), OS reduced-motion off.
- Expected: no JS motion (hero.js:4 and site.js:6 both OR in `root.classList.contains('calm')`). Actual: sections.js `reduce` ignores .calm, so the stats count-up (0→57 etc. via rAF over 1.2 s) and the reveal-on IntersectionObserver are armed. CSS html.calm neutralises the reveal transition, but the JS count-up still animates.
- Status: Confirmed · Severity: Low (user-chosen accessibility setting not honoured for one animation).
- Repro: qa-bug-hunt/repros/hero__calm_countup.mjs (.log) — fails: "reveal-on added despite html.calm" (count-up observers also armed).
- Root cause: inconsistent reduce computation; sections.js:10 lacks `|| document.documentElement.classList.contains('calm')`.

## HERO-3 · public/js/sections.js:163-178 (photo lightbox)
- Precondition: lightbox open with an image taller than the viewport (max-height calc(100vh-24px), overflow:auto, style3.css:2325) so it shows a scrollbar; user clicks/drags the scrollbar; or scrolls the wheel over the backdrop.
- Expected: same behaviour as the detail dialog (hero.js:259-266 tests the bounding box so scrollbar clicks don't close; html.has-dialog locks page scroll). Actual: `e.target === lb` closes the lightbox on a scrollbar click, and no has-dialog scroll lock is applied, so the page behind can scroll.
- Status: Suspected (browser-only) · Severity: Low.
- Manual steps: open http://127.0.0.1:8781/#/explore, resize window to ~600px tall, click a gallery photo, click the lightbox's vertical scrollbar → lightbox closes; reopen, wheel over the dark backdrop → page behind scrolls.
- Root cause: lightbox handler copies neither the box test nor the has-dialog lock used by the detail dialog.
