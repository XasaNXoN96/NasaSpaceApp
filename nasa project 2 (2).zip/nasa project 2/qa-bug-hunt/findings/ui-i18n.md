# Findings — partition ui-i18n (ui.js, i18n.js, i18n-strings.js, learn-data.js, present.js)

All repros: `node qa-bug-hunt/repros/<name>.mjs` (node:test + node:vm loading the real files; shared loaders
`ui__harness.mjs`, `ui__search_lib.mjs`). Verbatim output in the matching `.log`.

### UI-1 · ui.js:331-354 (ALIAS + search) · Confirmed · Medium
- RU/UZ visitor searches a native word → expected the items whose (translated) text contains it → actual ZERO results for "солнце", "буря", "вода", "сигнал", "антенна" (RU) and "quyosh", "suv" (UZ); "кратер" 1 vs 13, "tosh" 4 vs 12.
- Severity: search is broken for basic words in 2 of 3 site languages.
- Root cause: ALIAS replaces the word with English, but the index was translated (ui.js:326), so the English word is absent; the `known` fallback then keeps the unknown alias. Aliases should be OR-ed with the original word (or applied only in EN).
- Repro: repros/ui__alias_kills_ru_uz_search.mjs (6/6 fail, e.g. "буря" actual 0, expected 3).

### UI-2 · ui.js:369-375 (mark) · Confirmed · Low
- Multi-word query whose later word is a substring of `mark` or of an entity → expected highlighted text → actual markup injected inside tags: "spirit ma" (typing "spirit mars") gives `<<mark>ma</mark>rk>Spirit</<mark>ma</mark>rk>`; "amp" gives `R&<mark>amp</mark>;D`. Results render garbled (literal "rk>" fragments). Not XSS (only matched escaped text is reused).
- Root cause: each word is replaced sequentially on the already-marked HTML string. Build one alternation regex over the escaped text instead.
- Repro: repros/ui__mark_corrupts_html.mjs (2/2 fail).

### UI-3 · ui.js:344-349 (tag search) · Confirmed · Low
- RU/UZ: click a keyword chip, e.g. "#dust storm" → expected spacecraft + glossary entry (as in EN) → actual Glossary hit missing.
- Root cause: tag stays English (`data-tag`), but Glossary is matched by substring of translated `nt`/`nx`. Match against the English title/text (or `ng`).
- Repro: repros/ui__tag_search_drops_glossary_ru.mjs (ru+uz fail: kinds [Spacecraft] vs [Glossary, Spacecraft]).

### UI-4 · ui.js:438 (glossary round) / learn-data.js pale-blue-dot · Confirmed · Low
- EN glossary round → expected the definition's first sentence → actual "Which term means: “The photo of Earth Voyager 1 took on Feb”?" (`split('. ')` cuts at "Feb. 14"). RU/UZ unaffected (i18n rule re-reads full DICT entry).
- Root cause: naive sentence split on ". " meets an abbreviation. Fix the split or reword the definition.
- Repro: repros/ui__glossary_question_truncated.mjs.

### UI-5 · ui.js:90 + i18n.js:44 (reGB) · Confirmed · Low
- RU/UZ, badge unlocked in September → expected translated date → actual "Открыто 5 Sept 2026" / "Ochilgan: 5 Sept 2026".
- Root cause: `toLocaleDateString('en-GB',{month:'short'})` returns "Sept" (current ICU: Chrome, Node 24); reGB only accepts "Sep" (MONTHS already has Sept).
- Repro: repros/ui__badge_date_sept_untranslated.mjs (2/2 fail).

### UI-6 · ui.js:150 (reset confirm) · Confirmed · Low
- RU/UZ: Settings › Reset → expected translated confirm dialog (key exists in I18N_STRINGS) → actual English "Reset all achievements and progress on this device?".
- Root cause: confirm() text is not a DOM node, so the i18n MutationObserver never sees it; wrap in `window.T`.
- Repro: repros/ui__reset_confirm_untranslated.mjs (static + real T check).

### UI-7 · ui.js:11-19, 56-59, 493 (store/count) · Confirmed · Low
- localStorage `spaceedu.tally` = `{"terms":5}` (old/foreign value) → expected fallback (per comment at :11) → actual `TypeError: list.indexOf is not a function` in count(); same for `films` in renderFilms (`seen.indexOf`) at start-up.
- Root cause: only the top-level type is validated; nested values assumed arrays.
- Repro: repros/ui__tally_corrupt_throws.mjs.

### UI-8 · ui.js:156 (autoflat) × sound.js:15,211 · Confirmed · Medium
- First visit on cellular/data-saver (data-autoflat) → visitor only toggles sound/volume/voice → expected auto-2D to stay "in memory only" → actual `{"quality":"2d"}` saved; every later visit (even Wi-Fi) is flat via index.html:35 and the "Load 3D" toast never shows again.
- Cross-partition: sound.js `set()` saves the whole shared cfg object.
- Repro: repros/ui__autoflat_quality_persisted.mjs (saved quality "2d").

### UI-9 · ui.js:196-200 (glossary filter) · Confirmed · Low
- UZ Glossary page, type `qo'nish` (ASCII apostrophe, as keyboards produce) → expected "Qo‘nish moduli" card → actual "0 of 36 terms". The search dialog folds ‘’→' via norm(); this filter does not.
- Repro: repros/ui__glossary_filter_apostrophe_uz.mjs.

### UI-10 · ui.js:147 (language menu) · Confirmed · Low (a11y)
- Open EN/RU/UZ menu, press Escape → expected aria-expanded="false" → actual stays "true" (outside-click path at :146 resets it).
- Repro: repros/ui__lang_menu_escape_aria.mjs.

### UI-11 · ui.js:314,326 (search timeline items) · Confirmed · Low
- RU/UZ search results of type Timeline → expected translated title → actual English, 39/39 (e.g. "July 16, 1969 · Apollo 11 laser retroreflector"); no DICT key/RULE for "<date> · <object>".
- Repro: repros/ui__timeline_titles_untranslated.mjs.

### UI-12 · present.js:44,54,67 (keyboard after Next/Prev disables) · Suspected · Medium
- Presentation mode (P), press Enter/Space on the focused "Next" button until slide 6 → expected arrow keys keep working → suspected: the focused .pr-next becomes `disabled`, focus falls back to <body> (focus fixup), and keydown no longer reaches the `dlg` listener, so ←/Home stop working until the user clicks inside. Same at slide 1 with Prev.
- Unverified (browser-only): whether Chrome moves focus to body or keeps it in the dialog. Manual: open site, press P, Tab to Next, press Enter 5×, then press ← — check whether slide changes and what `document.activeElement` is.
- Fix idea: move focus to the other button (or dlg) before disabling.

### Checked, no bug found
i18n key coverage of every English literal in ui.js/present.js plus all GLOSSARY t/d, QUESTIONS, TAGS (RU+UZ: no misses; ru/uz key sets identical, no whitespace-mismatched keys, no empty values); quiz answers vs data.js (16 missions Qs, status labels, STATUS_WHY all consistent); localStorage try/catch in i18n.js, store, setLang; search with empty/whitespace query, "#", regex specials ( [ \ . ; XSS via query (all output escaped; mark reuses escaped text only); Uzbek ‘/’ and Cyrillic й/ё normalisation in the search dialog; T() whitespace/lead/tail handling; plural rules; present.js timer cleanup on close/Esc and slide bounds.
